There is no documentation at the moment apart from the comments in the source code.  This code relies on my LukesBits library, which provides a custom vector class so the tree can be integrated into my raytracer.

http://www.lukewallin.co.uk/graphics/java_trees for more info, or email me at luke.wallin@gmail.com if you have any questions!