/*
 * JavaTree - 3D tree generation library and demo GUI
    Copyright (C) 2012 Luke Wallin

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package javatree;

/**
 *
 * @author Luke
 */
//grow the tree, do nothing with the camera
class GrowTree implements Runnable {

    public Tree tree;
    public double growFor;

    public GrowTree(Tree _tree, double _growFor) {//TreeWindow _window){
        tree = _tree;
        growFor = _growFor;

    }

    public void run() {

        double time = 0;
        while (time < growFor) {

            try {
                Thread.sleep(34);//10

                //
                //if(time < growFor){
                time += 0.2;
                tree.grow(0.2);
                //}

                //testAngle+=0.02;

                //Vector h = new Vector(0,0,100);

                //Vector rotatedAngle = h.rotate(new Vector(1,0,0), testAngle);

                //trunk.hackSetAngle(new Vector(0,Math.cos(testAngle),Math.sin(testAngle)));
                //grow(0);
                //trunk.rotate(new Vector(1,0,0), 0.02);

                //cameraAngle+=0.025;//Math.PI/128;//256

                /*if(cameraAngle > Math.PI*2){
                cameraAngle = -Math.PI*2;
                }*/



            } catch (InterruptedException e) {
            }

        }
    }
}