Fractal generator written in Java.  Doesn't do much any other fractal generator doesn't do.

Controls:

Drag mouse or use arrow keys to move around
mouse scroll wheel to zoom (need to add keyboard ability to do this)
print screen to take screenshot (including hi-rez version!)
+/- keys to change detail

Released under LGPL.  

Website: http://www.lukewallin.co.uk/graphics/fractals

luke.wallin@gmail.com