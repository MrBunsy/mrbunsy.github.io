/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package GUIChainReaction;

import ClientChainReaction.Client;
import java.awt.*;
import java.net.*;
import java.io.*;

/**
 *
 * @author Luke
 */
public class GUIChainReaction extends ChainReactionBase.ChainReaction {

    private int cellSize;
    private int boardWidth;
    private int boardHeight;
    private int offsetX;
    private int offsetY;
    //private GUI gui;
    //private boolean weAreServer;
    //private boolean weAreClient;
    // String connectTo;
    //private int port;
    //which player we are
    //private int us;
    //private Client client;
    private Controller controller;
    
    private int whosGo;
    //private Socket socket;
    
    public Color GetPlayerColor(int player){
        return ColourToColor(players[player].Colour());
    }
    
    public Color ColourToColor(ChainReactionBase.Colour colour){
        switch (colour) {
            case Red:
                return Color.red;
                //break;
            case Orange:
                return Color.orange;
                //break;
            case Yellow:
                return Color.yellow;
                //break;
            case Green:
                return Color.green;
                //break;
            case Blue:
                return Color.blue;
                //break;
            case Purple:
            default://TODO make real purple
                return Color.pink;
                //break;
        }
    }
    
  
    /*public void SetGUI(GUI _gui){
        gui=_gui;
        gui.DisplayText("Player "+(whosGo+1)+"'s Go", ColourToColor(players[whosGo].Colour()));
    }*/

    //plan, keep this class, but get anotehr class to be the one that luanches the GUI, taht way this can be laucnhed once the number of players is actually known
    public GUIChainReaction(int width, int height, int _players, Controller _controller,int _whosGo) {
        super(width, height, _players);
        cellSize=64;
        offsetX=32;
        offsetY=32;
        boardWidth=cellSize*width;
        boardHeight=cellSize*height;
        //whosGo=(int)Math.floor(Math.random()*_players);
        whosGo=_whosGo;
        controller=_controller;
        //controller.LocalThinksWhosGo(whosGo);
    }
    
    public void SetWhosGo(int go){
        whosGo=go;
    }
    
    public int GetWhosGo(){
        return whosGo;
    }

    //used by local game
    public void MouseClick(int x, int y){
        MouseClick(x,y,whosGo);
    }
    
    //find a cell from the mouse location
    public CellLocation FindCell(int x, int y){
        x-=offsetX;
        y-=offsetY;
        if(x>0 && x < boardWidth && y>0 && y< boardHeight){
            //in the board
            int cellX=(int)Math.floor(x/cellSize);
            int cellY=(int)Math.floor(y/cellSize);
            return new CellLocation(cellX,cellY);
        }
        
        return null;
    }
    
    //used by network game with the local client as whoclicked
    public boolean MouseClick(int x, int y,int whoClicked){
        boolean result=false;
        if(board.GameOver()){
            return false;
        }
        if(whoClicked==whosGo){

            x-=offsetX;
            y-=offsetY;
            if(x>0 && x < boardWidth && y>0 && y< boardHeight){
                //in the board
                int cellX=(int)Math.floor(x/cellSize);
                int cellY=(int)Math.floor(y/cellSize);
                result=AddBomb(cellX,cellY);
            }
        controller.Repaint();
        }
        
        return result;
    }
    
    public boolean AddBomb(int cellX, int cellY){
        if(board.AddBomb(players[whosGo],cellX,cellY)){
                    //GetCell(cellX, cellY).
                    //successfully added a bomb here
                    if(board.Explode()){
                        //game has been won
                        //gui.DisplayText("GAME OVER. Player "+(whosGo+1)+" WON",ColourToColor(players[whosGo].Colour()) );
                        controller.LocalThinksGameWon(whosGo);
                        controller.Repaint();
                        //gui.repaint();
                        return true;
                    }
                    do{
                    whosGo++;
                    whosGo%=players.length;
                    }while(!board.IsPlayerAlive(players[whosGo]));
                    
                    //gui.DisplayText("Player "+(whosGo+1)+"'s Go", ColourToColor(players[whosGo].Colour()));
                    controller.LocalThinksWhosGo(whosGo);
                    return true;
                }
        return false;
    }
    
    public void DrawBoard(Graphics g){
        
        g.setColor(Color.black);
        g.fillRect(offsetX, offsetY, boardWidth+1, boardHeight+1);
        
        for(int x=0;x<=width;x++){
            drawDashedLine(g,offsetX+x*cellSize,offsetY,offsetX+x*cellSize,offsetY+boardHeight,Math.round(cellSize/16));
        }
        for(int y=0;y<=height;y++){
                drawDashedLine(g,offsetX,offsetY+y*cellSize,offsetX+boardWidth,offsetY+y*cellSize,Math.round(cellSize/16));
            }
        
        for(int x=0;x<width;x++){
            for(int y=0;y<height;y++){
                ChainReactionBase.Cell c = board.GetCell(x,y);
                int bombs=c.Bombs();
                ChainReactionBase.Player p = c.Owner();
                
                ChainReactionBase.Colour colour = ChainReactionBase.Colour.Red;
                
                if(p!=null){
                    colour=p.Colour();
                }
                
                DrawBombs(g,offsetX+x*cellSize,offsetY+y*cellSize,bombs,colour);
            }
        }
    }
    
    private void drawDashedLine(Graphics g, int x1, int y1, int x2, int y2, int cycle) {
		// Draw a line from 'x1,y1' to 'x2,y2'.
		// The line is broken into segments which are each 'cycle' pixels long. 
		//int counter = 0;
                g.setColor(Color.white);
		int dx = x2-x1;
		int dy = y2-y1;
		double dz = Math.sqrt((double) (dx*dx + dy*dy));
		cycle = cycle * 2;
		for (int z = 0; z<=dz; z++) {
			int x = (int) (x1 + dx * z/dz);
			int y = (int) (y1 + dy * z/dz);
			if (z % cycle < cycle / 2) {
				g.drawLine(x, y, x, y);
			}
		}
	}
    
    //also stoled
    public void DrawBombs(Graphics g, int x, int y, int bombs, ChainReactionBase.Colour who) {
        // Render an image of 'bombs' number of bombs, belonging to 'who'.
        // This is executed once (for each combination) at the start,
        // with the output saved for rapid reuse.
        // If you want to use external PNGs of bomb clusters, this is where to add it.
        //Image img = this.createImage(63, 63);
        //Graphics g = img.getGraphics();
        //g.setColor(Color.black);
        //g.fillRect(0, 0, 64, 64);

        if (bombs == 0) {
            // Done.
        } else if (bombs == 1) {
            drawBomb(g, x + 20, y + 19, who);
        } else if (bombs == 2) {
            drawBomb(g, x + 7, y + 19, who);
            drawBomb(g, x + 35, y + 19, who);
        } else if (bombs == 3) {
            drawBomb(g, x + 7, y + 31, who);
            drawBomb(g, x + 21, y + 5, who);
            drawBomb(g, x + 35, y + 32, who);
        } else if (bombs == 4) {
            drawBomb(g, x + 9, y + 5, who);
            drawBomb(g, x + 33, y + 33, who);
            drawBomb(g, x + 33, y + 5, who);
            drawBomb(g, x + 9, y + 33, who);
        } else if (bombs == 5) {
            drawBomb(g, x + 1, y + 10, who);
            drawBomb(g, x + 21, y + 2, who);
            drawBomb(g, x + 41, y + 10, who);
            drawBomb(g, x + 9, y + 35, who);
            drawBomb(g, x + 33, y + 36, who);
        } else { // Six or more bombs
            drawBomb(g, x + 1, y + 10, who);
            drawBomb(g, x + 21, y + 2, who);
            drawBomb(g, x + 41, y + 10, who);
            drawBomb(g, x + 1, y + 36, who);
            drawBomb(g, x + 21, y + 28, who);
            drawBomb(g, x + 41, y + 36, who);
        }
        //return img;
    }

    //stoled from Neil Fraser - TODO make mine
    private void drawBomb(Graphics g, int x, int y, ChainReactionBase.Colour colour) {
        // Draw a single bomb at the given coordinates, coloured for the given player.
        // Only called by getBombImage which draws the clusters.
        Color c_fuse = Color.lightGray;
        Color c_text;
        Color c_body;
        switch (colour) {
            case Red:
                c_text = Color.red;
                c_body = Color.red;
                break;
            case Orange:
                c_text = Color.orange;
                c_body = Color.orange;
                break;
            case Yellow:
                c_text = Color.yellow;
                c_body = Color.yellow;
                break;
            case Green:
                c_text = Color.green;
                c_body = Color.green;
                break;
            case Blue:
                c_text = Color.blue;
                c_body = Color.blue;
                break;
            case Purple:
            default://TODO make real purple
                c_text = Color.pink;
                c_body = Color.pink;
                break;
        }

        g.setColor(c_body);
        g.fillOval(x + 1, y + 7, 19, 19);
        g.fillRect(x + 6, y + 5, 9, 10);

        g.setColor(c_text);
        g.drawLine(x + 6, y + 12, x + 14, y + 20);
        g.drawLine(x + 6, y + 20, x + 14, y + 12);
        g.drawLine(x + 6, y + 13, x + 13, y + 20);
        g.drawLine(x + 6, y + 19, x + 13, y + 12);
        g.drawLine(x + 7, y + 12, x + 14, y + 19);
        g.drawLine(x + 7, y + 20, x + 14, y + 13);

        g.drawLine(x + 8, y + 12, x + 8, y + 12);
        g.drawLine(x + 12, y + 12, x + 12, y + 12);
        g.drawLine(x + 8, y + 20, x + 8, y + 20);
        g.drawLine(x + 12, y + 20, x + 12, y + 20);

        g.setColor(c_fuse);
        g.drawLine(x + 10, y + 1, x + 10, y + 4);
        g.drawLine(x + 11, y + 0, x + 14, y + 0);
        g.drawLine(x + 11, y + 1, x + 11, y + 1);
    }
}
