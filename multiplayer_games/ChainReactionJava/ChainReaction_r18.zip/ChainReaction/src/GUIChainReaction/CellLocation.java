/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package GUIChainReaction;

/**
 *
 * @author Luke
 */
public class CellLocation {
    public int x;
    public int y;
    public CellLocation(int _x, int _y){
        x=_x;
        y=_y;
    }
}
