package GUIChainReaction;
import java.awt.*;
import ClientChainReaction.*;
import java.net.*;
import java.util.ArrayList;
import ChainReactionBase.Board;
/**
 *
 * @author Luke
 */
public class Controller implements ClientController{
    private gui gui;
    private GUIChainReaction cr;
    private int whosGo;
    private boolean local;
    private Client client;
    private boolean ourGo;
    private int us;
    
    private ArrayList<String> playerNames;
    
    //default to 5x5, two players local game
    public Controller(){
        this(5,5,2);
    }
    //local match
    public Controller(int width,int height,int players){
        //just a local game
        local=true;
        
        gui=new gui(this);
        gui.setVisible(true);
        cr=new GUIChainReaction(width,height,players,this,(int)Math.floor(Math.random()*players));
        
        //cr.SetGUI(gui);
        
        //set the text
        LocalThinksWhosGo(cr.GetWhosGo());
    }
    
    public Controller(String host,int port){
        Socket socket = ChainReactionBase.Client.GetSocket(host, port);
        local=false;
        client = new Client(socket,this);
        
    }
    
    public synchronized void OurGo(){
        //it is our go! hurrah!
        ourGo=true;
    }
    
    public synchronized void MatchInfo(ArrayList<String> _playerNames,int width, int height,int startingPlayer, int _us){
        us=_us;
        if(startingPlayer==us){
            ourGo=true;
        }
        playerNames=_playerNames;
        cr=new GUIChainReaction(width,height,_playerNames.size(),this,startingPlayer);
        gui=new gui(this);
        gui.setVisible(true);
        
        gui.DisplayText(playerNames.get(startingPlayer)+" Go", cr.GetPlayerColor(startingPlayer));
    }
    
    public synchronized void BoardState(Board board){
        //this may not be needed
    }
    
    public synchronized void OpponentsGo(int opponent,int x, int y){
        cr.AddBomb(x, y);
        gui.DisplayText(playerNames.get(cr.GetWhosGo())+" Go", cr.GetPlayerColor(cr.GetWhosGo()));
        Repaint();
    }
    
    public synchronized void GameOver(int winner){
        gui.DisplayText(playerNames.get(winner)+" WON",cr.GetPlayerColor(winner) );
        client.StopListening();
    }
    
    public synchronized void Repaint(){
        gui.repaint();
    }
    
    public synchronized void LocalThinksGameWon(int winner){
        if(local){
            gui.DisplayText("GAME OVER. Player "+(winner+1)+" WON",cr.GetPlayerColor(winner) );
        }
    }
    
    public synchronized void LocalThinksWhosGo(int who){
        if(local){
            gui.DisplayText("Player "+(who+1)+"'s Go", cr.GetPlayerColor(who));
        }else{
            gui.DisplayText(playerNames.get(who)+" Go", cr.GetPlayerColor(who));
        }
    }
    //public void SetGUI(GUI _gui){
    //    gui=_gui;
    //}
    
    public void DrawBoard(Graphics g){
        if(cr!=null){
            //use this to draw the board whatever
            cr.DrawBoard(g);
        }
    }
    
    public void MouseClick(int x, int y){
        if(local){
            cr.MouseClick(x, y);
        }else{
            if(cr.MouseClick(x, y, us)){
                //bomb was placed
                CellLocation c=cr.FindCell(x, y);
                client.MyGo(c.x, c.y);
                System.out.println("had a go:("+c.x+","+c.y+")");
            }
        }
    }
    
    public void DisplayText(String text){
        
    }
}
