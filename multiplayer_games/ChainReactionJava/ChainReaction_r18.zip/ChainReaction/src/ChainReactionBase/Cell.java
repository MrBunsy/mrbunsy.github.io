package ChainReactionBase;

/**
 *
 * @author Luke
 */
public class Cell {

    //0=top, 1=right, 2= bottom, 3= left
    private Cell[] neighbours;
    private int bombs;
    private Player owner;

    public boolean AddBomb(Player player){
        if(CanAddBomb(player)){
            bombs++;
            owner=player;
            return true;
        }
        return false;
    }
    
    public boolean CanAddBomb(Player player){
        return owner == null || player==owner;
    }
    
    //another cell has exploded into this one
    public void ExplodeInto(Player player) {
        bombs++;
        owner = player;
    }

    //how many bombs in this cell
    public int Bombs() {
        return bombs;
    }
    
    public Player Owner(){
        return owner;
    }

    //this cell is now owned by someone else
    public void NewOwner(Player player) {
        owner = player;
    }

    //make us explode, return true if we did explode
    public boolean Explode() {
        boolean critical = IsCritical();
        if (critical) {
            for (int i = 0; i < 4; i++) {
                if (neighbours[i] != null) {
                    neighbours[i].ExplodeInto(owner);
                    bombs--;
                }
            }
        }
        
        if(bombs==0){
            owner=null;
        }
        
        return critical;
    }

    public boolean IsCritical() {
        return (Critical() <= bombs);
    }

    //how many bombs till this is critical?
    public int Critical() {

        int critical = 0;
        for (int i = 0; i < 4; i++) {
            if (neighbours[i] != null) {
                critical++;
            }
        }
        return critical;
    }

    public Cell() {
        bombs=0;
    }

    public void GiveNeighbours(Cell top, Cell right, Cell bottom, Cell left) {
        neighbours = new Cell[4];
        neighbours[0] = top;
        neighbours[1] = right;
        neighbours[2] = bottom;
        neighbours[3] = left;
    }
}
