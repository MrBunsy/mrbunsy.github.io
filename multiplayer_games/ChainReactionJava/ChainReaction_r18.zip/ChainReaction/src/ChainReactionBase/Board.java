package ChainReactionBase;


public class Board {
    private Cell[][] cells;
    private int width;
    private int height;
    
    private int turns;
    private int players;
    
    /*private Player[] players;
    
    public Player[] Players(){
        return players;
        
    }*/
    
    public boolean AddBomb(Player player, int x, int y){
        //return cells[x][y].AddBomb(player);
        if(cells[x][y].CanAddBomb(player)){
            cells[x][y].AddBomb(player);
            turns++;
            return true;
        }
        return false;
    }
    
    public Cell GetCell(int x,int y){
        return cells[x][y];
    }
    
    public boolean GameOver(){
        
        if(turns<players){
            //not been enough turns
            return false;
        }
        
        //int bombCount=0;
        Player p = null;
        
        for(int x=0;x<width;x++){
            for(int y=0;y<height;y++){
                Cell c = cells[x][y];
                //bombCount+=c.Bombs();
                Player thisP=c.Owner();
                //only if this cell is owned
                if(thisP!=null){
                    //the player from this cell is a different player from another cell
                    if(p!=thisP && p!=null){
                        //therefore there is more than one player, so the game ins't over.
                        return false;
                    }
                    //record who owned this cell so we can compare it
                    p=thisP;
                    
                }
            }
        }

        return true;
    }
    
    public boolean IsPlayerAlive(Player player){
        if(turns<players){
            return true;
        }
        for(int x=0;x<width;x++){
            for(int y=0;y<height;y++){
                Cell c = cells[x][y];
                //bombCount+=c.Bombs();
                Player thisP=c.Owner();
                if(thisP==player){
                    //this cell is owned by this player, therefore they still ahve bombs and are still int he game
                    return true;
                }
            }
        }
        
        
        return false;
    }
    
    public boolean Explode(){
        boolean exploded;
        boolean gameOver=false;
        do{
            exploded=false;
            //go through all the cells, if any exploded set exploded to true
            for(int x=0;x<width;x++){
                for(int y=0;y<height;y++){
                    //TODO here we will have to worry about animations for the GUI
                    if(cells[x][y].Explode()){
                        exploded=true;
                    }
                }
            }
            if(GameOver()){
                //don't get stuck in an infinite loop
                exploded=false;
                gameOver=true;
            }
            //keep going until an iteration shows nothign exploded
        }while(exploded);
        
        return gameOver;
    }
    
    public Board(int _width, int _height, int _players){
        
        turns=0;
        players=_players;
        width=_width;
        height=_height;
        
        cells = new Cell[width][height];
        
        //create all the cells
        for(int x=0;x<width;x++){
            for(int y=0;y<height;y++){
                cells[x][y]=new Cell();
            }
        }
        
        //go through and assign neighbours to all the cells
        for(int x=0;x<width;x++){
            for(int y=0;y<height;y++){
                Cell top=null;
                Cell right=null;
                Cell bottom=null;
                Cell left=null;
                
                if(x>0){
                    left = cells[x-1][y];
                }
                if(y>0){
                    top = cells[x][y-1];
                }
                if(x<width-1){
                    right = cells[x+1][y];
                }
                if(y<height-1){
                    bottom = cells[x][y+1];
                }
                
                cells[x][y].GiveNeighbours(top, right, bottom, left);
                
            }
        }
    }
}
