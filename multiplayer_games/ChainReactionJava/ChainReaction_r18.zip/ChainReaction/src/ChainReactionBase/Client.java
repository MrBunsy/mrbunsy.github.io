package ChainReactionBase;

import java.net.*;
import java.io.*;
import org.json.*;

import java.util.ArrayList;

/**
 *
 * @author Luke
 */
public class Client implements Runnable {

    protected Socket socket;
    protected PrintWriter out;
    //protected BufferedReader in;
    protected ListenToSocket listenToSocket;
    protected ArrayList<String> outList;
    
    protected boolean closeMe;

    //protected DataOutputStream out;
    //protected DataInputStream in;
    public Client(Socket _socket) {
        try {
            socket = _socket;

            out = new PrintWriter(socket.getOutputStream(), true);
            //in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            listenToSocket = new ListenToSocket(socket, this);
            listenToSocket.StartThread();


            outList = new ArrayList<String>();
            closeMe=false;

        } catch (IOException e) {
            System.err.println("Couldn't get I/O for the connection");
        }
    }

    public synchronized void StopListening(){
        //listenToSocket.Stop();
        try{
            socket.close();
        }catch(IOException e){
            System.err.println("failed to close socket");
        }
    }
    
    public static Socket GetSocket(String host,int port){
        InetAddress address=null;
        Socket _socket=null;
        
            try{
            address = InetAddress.getByName(host);
            //InetAddress address = InetAddress.getByName(connectTo);
            
            }catch(UnknownHostException e){
                System.out.println("Failed to find "+host);
                //gui.DisplayText("Failed to find "+connectTo, Color.red);
            }
            if(address!=null){
                try{
                _socket=new Socket(address,port);
                }catch(IOException e){
                    System.out.println("Failed to connect to "+host+":"+port);
                }
                
                //client=new Client(socket,this);
                //client.StartThread();
            }
            
        
        return _socket;
    }
    
    public void StartThread(){
        Thread t = new Thread(this);
        t.start();
        t.setName("clientClass");
    }
    
    public synchronized boolean IsAlive(){
        return !closeMe;
    }
    
    public synchronized void Close(){
        //this is probably very messy.
        closeMe=true;
    }
    
    public void SendThis(String send) {
        //outList.add(send);
        out.println(send);
    }

    public void CloseMe(){
        
    }
    
    // this client has sent stuff to us
    public synchronized void Input(String input) { 
        out.println("TODO override this method");
    }

    public void run() {
        while (!closeMe) {
            
            if (outList.size() > 0) {
                out.println(outList.remove(0));
            }
            
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
            }
            
        }/*
        String line;
        try {
            while ((line = in.readLine()) != null) {
                //tell the client input happened
                Input(line);

            }
            //socket has closed, shutdown client thread too
            //client.Close();
        } catch (IOException e) {
        }*/
        
        CloseMe();
    }
}

