
package ChainReactionBase;


public class ChainReaction {

    protected Board board;
    protected Player[] players;
    protected int width;
    protected int height;
    
    public ChainReaction(int _width, int _height, int _players){
        width=_width;
        height=_height;
        board = new Board(width,height,_players);
        
        players=new Player[_players];
        for(int p=0;p<_players;p++){
            players[p]=new Player(Colour.values()[p]);
        }
    }
    
    
    public synchronized int Width(){
        return width;
    }
    
    public synchronized int Height(){
        return height;
    }
    
    public synchronized boolean GameOver(){
        return board.GameOver();
    }
}
