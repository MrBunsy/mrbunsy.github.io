package ChainReactionBase;

//import java.awt.color.*;

public class Player {
    
    
    private Colour colour;
    //for win detection
    private boolean hadFirstGo;
    
    public boolean HadFirstGo(){
        return hadFirstGo;
    }
    
    public Player(Colour _colour){
        colour=_colour;
        hadFirstGo=false;
    }
    
    public Colour Colour(){
        return colour;
    }
    
}
