package ChainReactionBase;

public enum Colour {Red, Blue, Green, Yellow, Orange, Purple};
