package ChainReactionBase;

import java.net.*;
import java.io.*;
/**
 *
 * @author Luke
 */
public class ListenToSocket implements Runnable {

    protected Socket socket;
    protected Client client;
    protected BufferedReader in;
    protected boolean stop;

    public ListenToSocket(Socket _socket, Client _client) {
        socket = _socket;
        client = _client;

        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            System.err.println("Couldn't get input for the socket");
        }
        stop=false;
    }

    public synchronized void Stop(){
        stop=true;
    }
    
    public void StartThread() {
        Thread t = new Thread(this);
        t.start();
        t.setName("ListenToSocketClass");
    }

    public void run() {

        String line;
        try {
            while ((line = in.readLine()) != null && !stop) {
                //tell the client input happened
                client.Input(line);

            }
            //socket has closed, shutdown client thread too
            client.Close();
        } catch (IOException e) {
            client.Close();
        }
    }
}