package LukesChainReaction;

import jargs.gnu.*;

/**
 *
 * @author Luke
 */
public class LaunchChainReaction {

    private static void printUsage() {
        System.err.println(
                "Usage: ChainReaction [-s,--server]  [-p,--port]\n"
                + "                  [-c,--client]/[b,--bot] [-p,--port] [-h,--host] \n"
                + "                   [-g,--gui]");
    }

    public static void main(String[] args) {

        CmdLineParser parser = new CmdLineParser();
        CmdLineParser.Option serverArg = parser.addBooleanOption('s', "server");
        CmdLineParser.Option loginArg = parser.addBooleanOption('l', "login");
        CmdLineParser.Option clientArg = parser.addBooleanOption('c', "client");
        CmdLineParser.Option botClientArg = parser.addBooleanOption('b', "bot");
        CmdLineParser.Option guiArg = parser.addBooleanOption('g', "gui");
        CmdLineParser.Option portArg = parser.addIntegerOption('p', "port");
        CmdLineParser.Option hostArg = parser.addStringOption('h', "host");
        CmdLineParser.Option playerArg = parser.addIntegerOption("players");
        CmdLineParser.Option widthArg = parser.addIntegerOption("width");
        CmdLineParser.Option heightArg = parser.addIntegerOption("height");

        try {
            parser.parse(args);
        } catch (CmdLineParser.OptionException e) {
            System.err.println(e.getMessage());
            printUsage();
            System.exit(2);
        }

        boolean server = (boolean) parser.getOptionValue(serverArg, false);
        boolean login = (boolean)parser.getOptionValue(loginArg, false);
        boolean client = (boolean) parser.getOptionValue(clientArg, false);
        boolean bot = (boolean) parser.getOptionValue(botClientArg, false);
        boolean gui = (boolean) parser.getOptionValue(guiArg, false);
        int port = (int) parser.getOptionValue(portArg, 1234);
        String host = (String) parser.getOptionValue(hostArg, "localhost");
        int players = (int)parser.getOptionValue(playerArg,2);
        int width = (int)parser.getOptionValue(widthArg,5);
        int height = (int)parser.getOptionValue(heightArg,5);

        if (server) {
            System.out.println("Hosting Server");
            ServerChainReaction.Server s = new ServerChainReaction.Server(login);
            ServerChainReaction.Listener l = new ServerChainReaction.Listener(port, 0);
            s.StartThread();

            l.Listen(s);
        } else if (client) {
            System.out.println("GUI Client");
            new GUIChainReaction.Controller(host, port);
        } else if (gui) {
            System.out.println("GUI Local");
           new GUIChainReaction.Controller(width,height,players);
        } else if (bot) {
            System.out.println("Bot Client");
        } else {
            printUsage();
        }

    }
}
