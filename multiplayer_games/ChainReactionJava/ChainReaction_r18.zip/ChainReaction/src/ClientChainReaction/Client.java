package ClientChainReaction;

import GUIChainReaction.GUIChainReaction;
import java.net.*;
import java.io.*;
import org.json.*;
import java.util.ArrayList;
/**
 *
 * @author Luke
 */
public class Client extends ChainReactionBase.Client{

    private ClientController controller;
    public Client(Socket _socket,ClientController _controller){
        super(_socket);
        controller=_controller;
    }
    
    //something FROM the server
    public synchronized void Input(String input) { 
         try {
            JSONObject j = new JSONObject(input);
            String command = j.getString("command");


            switch(command) {
                case "matchInfo":
                    JSONArray jsonNames = j.getJSONArray("opponents");
                    ArrayList<String> names = new ArrayList<String>();
                    for(int i=0;i<jsonNames.length();i++){
                        names.add(jsonNames.optString(i));
                    }
                    controller.MatchInfo(names, j.getInt("width"), j.getInt("height"), j.getInt("startingPlayer"), j.getInt("you"));
                break;
                case "theirGo":
                    controller.OpponentsGo(j.getInt("player"), j.getInt("x"), j.getInt("y"));
                    break;
                case "gameOver":
                    controller.GameOver(j.getInt("winner"));
                    break;
            }

        } catch (JSONException e) {
            System.out.println("Malformed JSON from server");
        }
    }
    
    public synchronized void MyGo(int x, int y){
        JSONObject j = new JSONObject();
        try{
            j.put("command", "myGo");
            j.put("x", x);
            j.put("y", y);
        } catch (JSONException e) {
            System.out.println("failed setting MyGo json");
        }
        SendThis(j.toString());
    }
    
    private void closeMe(){
        //called when the socket shutsdown
        System.out.println("Lost connection to server");
    }
}
