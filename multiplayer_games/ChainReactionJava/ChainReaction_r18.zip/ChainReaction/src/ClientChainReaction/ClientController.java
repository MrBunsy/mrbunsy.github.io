package ClientChainReaction;
import java.util.ArrayList;
import ChainReactionBase.Board;
/**
 *
 * @author Luke
 */
public interface ClientController {
    
    //this client's go
    public void OurGo();
    
    public void MatchInfo(ArrayList<String> playerNames,int width, int height,int startingPlayer, int us);
    
    public void OpponentsGo(int opponent,int x, int y);
    
    public void BoardState(Board board);
    
    public void GameOver(int winner);
}
