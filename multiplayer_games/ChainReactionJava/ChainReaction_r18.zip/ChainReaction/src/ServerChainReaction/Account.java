/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ServerChainReaction;

/**
 *
 * @author Luke
 */
public class Account {
    private String username;
    
    public Account(String _username){
        username=_username;
    }
    
    public String getUsername(){
        return username;
    }
}
