package ServerChainReaction;

import java.io.*;
import java.util.Date;

/**
 *
 * @author Luke
 */
public class Log {

    public static void LogText(String text) {
        try {
            Date date = new Date();
            
            
            String logMe = date.toString()+":"+text;
            // Create file 
            FileWriter fstream = new FileWriter("log.txt",true);
            BufferedWriter out = new BufferedWriter(fstream);
            out.write("\r\n"+logMe);
            //out.append("\n"+logMe);
            //Close the output stream
            out.close();
            
            System.out.println(logMe);
            
        } catch (Exception e) {//Catch exception if any
            System.err.println("Error: " + e.getMessage());
        }
    }
}
