/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ServerChainReaction;

import ChainReactionBase.*;
import java.util.ArrayList;
import java.io.*;
import org.json.*;

/**
 *
 * @author Luke
 */
public class Match extends ChainReaction {

    private ChainReaction match;
    private ArrayList<Client> playerClients;
    private int whosGo;
    private int matchNumber;
    //private int width;
    //private int height;

    public Match(int _width, int _height, ArrayList<Client> clients, int start) {
        super(_width, _height, clients.size());
        playerClients = clients;
        //width=_width;
        //height=_height;

        //match = new ChainReaction(width, height, clients.size());
        //matchNumber=GetMatchNumber();
        
        
        whosGo = start;
    }
    
    private void logMatch(){
        JSONObject log = new JSONObject();
        try {
        log.put("matchNumber", matchNumber);
        
        JSONArray goes = new JSONArray();
        
         } catch (JSONException e) {
            System.out.println("execption building json for yourGo");
        }
    }
    
    //reads from db/flat file system how many matches there have been and returns increment
    public static int GetMatchNumber(){
        
        int matches = 1;
        try{
        FileReader readFile = new FileReader("matches.txt");
        BufferedReader bufRead = new BufferedReader(readFile);
        
        String line=bufRead.readLine();
        
        matches = Integer.parseInt(line)+1;
        
        bufRead.close();
        //readFile.close();
        
        
        
        }catch(IOException e){
            System.out.println("failed to read matches.txt, assuming first match");
        }
        
        try{
            
            FileWriter fstream = new FileWriter("matches.txt");
            BufferedWriter out = new BufferedWriter(fstream);
            out.write(matches);
            
            out.close();
            
            return matches;
            
        }catch(IOException e){
             System.out.println("failed to write to matches.txt HELP PANIC");
        }
        
        return matches;
    }

    public void Start() {
        int i = 0;
        for (Client c : playerClients) {
            c.StartMatch(this, i);
            i++;
        }
    }

    public synchronized int WhosGo() {
        return whosGo;
    }

    public String[] PlayerNames() {
        String[] names = new String[playerClients.size()];
        for (int i = 0; i < playerClients.size(); i++) {
            names[i] = "Player " + (i + 1);
        }

        return names;
    }

    public synchronized boolean Go(Client client, int x, int y) {
        int player = playerClients.lastIndexOf(client);
        Log.LogText("player int: " + player + " whosGo:" + whosGo);
        if (player == whosGo) {

            if (x >= 0 && y >= 0 && x < width && y < height && board.AddBomb(players[player], x, y)) {

                //int p=playerClients.indexOf(client);

                boolean gameWon=board.Explode();

                if(!gameWon){
                //advance who's go
                    do {
                        whosGo++;
                        whosGo %= players.length;
                    } while (!board.IsPlayerAlive(players[whosGo]));
                //Log.LogText("now player " + whosGo + "'s turn");
                }
                
                for (Client c : playerClients) {
                    if (c != client) {
                        //not us, tell them we just had a go
                        c.OpponentsGo(player, x, y,whosGo,gameWon);
                    }
                    if(gameWon){
                        //tell everyone the game's over
                        c.GameWon(whosGo);
                    }
                }
                
                if(!gameWon){
                        //tell the player who's next that it's their go.
                        playerClients.get(whosGo).ThisPlayersGo();
                    }
                
                return true;
            } else {
                Log.LogText("couldn't place bomb there");
            }
        }

        return false;

    }
}
