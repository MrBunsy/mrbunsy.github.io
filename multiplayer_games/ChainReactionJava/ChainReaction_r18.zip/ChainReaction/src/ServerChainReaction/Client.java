/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ServerChainReaction;

import java.net.*;
import java.io.*;
import org.json.*;

import java.util.ArrayList;

/**
 *
 * @author Luke
 */
public class Client extends ChainReactionBase.Client{

    private Server server;
    private boolean loggedIn;
    private String username;
    
    private boolean inMatch;
    private Match match;
    
    //us in the list of players f or a match
    private int us;
    

    //private DataOutputStream out;
    //private DataInputStream in;
    public Client(Socket _socket, Server _server) {
        super(_socket);

        server = _server;
        inMatch=false;
    }

    public synchronized void ThisPlayersGo(){
        JSONObject reply = new JSONObject();
        try {
        reply.put("command", "yourGo");
        
         } catch (JSONException e) {
            System.out.println("execption building json for yourGo");
        }
        SendThis(reply.toString());
        Log.LogText(reply.toString());
    }
    
    public synchronized void OpponentsGo(int player,int x, int y, int whosNext,boolean winningMove){
        JSONObject reply = new JSONObject();
        try {
        reply.put("command", "theirGo");
        reply.put("x",x);
        reply.put("y",y);
        reply.put("player",player);
        reply.put("next",whosNext);
        reply.put("winningMove",winningMove);
        
         } catch (JSONException e) {
            System.out.println("execption building json for match details");
        }
        SendThis(reply.toString());
        Log.LogText(reply.toString());
    }
    public synchronized void GameWon(int winner){
        JSONObject reply = new JSONObject();
        try {
        reply.put("command", "gameOver");
        reply.put("winner",winner);
        
         } catch (JSONException e) {
            System.out.println("execption building json for match details");
        }
        SendThis(reply.toString());
        Log.LogText(reply.toString());
    }
    
    public synchronized void StartMatch(Match _match, int us){
        match=_match;
        inMatch=true;
        //inform the client
        
        JSONObject reply = new JSONObject();
        try {
        reply.put("command", "matchInfo");
        reply.put("game","cr");
        reply.put("startingPlayer",match.WhosGo());
        reply.put("width",match.Width());
        reply.put("height",match.Height());
        
        JSONArray names = new JSONArray(match.PlayerNames());
        
        reply.put("opponents", names);
        
        reply.put("you",us);
         } catch (JSONException e) {
            System.out.println("execption building json for match details");
        }
        SendThis(reply.toString());
        Log.LogText(reply.toString());
    }
    
    
    // this client has sent stuff to us

    public synchronized void Input(String input) {
        Log.LogText(input);
        JSONObject reply = new JSONObject();

        try {
            JSONObject j = new JSONObject(input);
            String command = j.getString("command");

            boolean noPerms=false;
            
            switch(command){
                case "login":
                    if(server.RequireLogin()){
                        loggedIn = true;
                        username = j.getString("username");
                        reply.put("command", "loginSuccess");
                    }else{
                        reply.put("command", "error");
                        reply.put("details","Logins not enabled on server");
                    }
                    break;
                case "myGo":
                    //Log.LogText("someone's go");
                    if(inMatch){
                        if(match.Go(this, j.getInt("x"),j.getInt("y"))){
                            reply.put("command","success");
                        }else{
                            reply.put("command", "invalidMove");
                        }
                    }else{
                        reply.put("command", "error");
                        reply.put("details","Not currently in a match");
                    }
                    break;
                default:
                    reply.put("command", "error");
                    reply.put("details", "Command not recognised or insufficient permissions");
                    break;
            }
            

            out.println(reply.toString());
        } catch (JSONException e) {
            out.println("{command:\"error\",details:\"Malformed JSON\"}");
        }

        //mainServer.BroadCast(input);
    }

    public void CloseMe(){ 
        server.LoseClient();
        Log.LogText("Client "+socket.getInetAddress().getHostAddress()+" closed connection");
    }
}