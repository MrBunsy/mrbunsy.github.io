/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ServerChainReaction;

import java.net.*;
import java.io.*;


/**
 *
 * @author Luke
 */
public class Listener {

    private int port;
    private int maxConnections;
    
    //private ArrayList<Client> clients;

    // Listen for incoming connections and handle them
    public static void main(String[] args) {
        
        Server server= new Server(false);
        Listener s = new Listener(1234,0);
        server.StartThread();
        
        s.Listen(server);
    }
    
    public Listener(int _port, int _maxConnections){
        port=_port;
        maxConnections=_maxConnections;
    }
    
    public void Listen(Server server){
        int i = 0;
        Log.LogText("Listening on port "+port);
        try {
            ServerSocket listener = new ServerSocket(port);
            //Socket server;

            while ((i++ < maxConnections) || (maxConnections == 0)) {
                //doComms connection;
                Socket socket = listener.accept();
                
                Client client = new Client(socket,server);
                server.NewClient(client);
                InetAddress clientAddress = socket.getInetAddress();
                Log.LogText("New Client: "+clientAddress.getHostAddress()+":"+socket.getPort());
                //clients.add(client);
                client.StartThread();
            }
        } catch (IOException ioe) {
            Log.LogText("IOException on socket listen: " + ioe);
            ioe.printStackTrace();
        }
    }
}
