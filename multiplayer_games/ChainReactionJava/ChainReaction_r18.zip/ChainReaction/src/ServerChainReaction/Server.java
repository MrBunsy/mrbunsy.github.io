
package ServerChainReaction;
import java.util.ArrayList;
import java.io.*;
/**
 *
 * @author Luke
 */
public class Server implements Runnable{
    
    private ArrayList<Client> clients;
    private ArrayList<Match> matches;
    private boolean requireLogins;
    
    public void run(){
        while(true){
            //organise clients
            try{
                Thread.sleep(100);
            }catch(InterruptedException e){
                
            }
        }
    }
    
    public boolean RequireLogin(){
        return requireLogins;
    }
    
    public Server(boolean logins){
        requireLogins=logins;
        clients = new ArrayList<Client>();
        matches = new ArrayList<Match>();
    }
    
    public synchronized void LoseClient(){
        //search through clients to cull any who've died
        for(int i=0;i<clients.size();i++){
            Client c=clients.get(i);
            if(!c.IsAlive()){
                clients.remove(i);
                i--;
            }
        }
    }
    
    public synchronized void BroadCast(String broadcast){
        for(Client c : clients){
            c.SendThis(broadcast);
        }
        System.out.println("broadcast: "+broadcast);
    }
    
    public synchronized boolean Login(String username, String password){
        //TODO: account system
        return true;
    }
    
    public void StartThread(){
        Thread t = new Thread(this);
        t.start();
        t.setName("ServerClass");
    }
    
    public synchronized void NewClient(Client newClient){
        clients.add(newClient);
        
        //temp logic for testing
        if(clients.size()==2){
            //start a match
            Match m = new Match(6,6,clients,0);
            matches.add(m);
            m.Start();
        }
    }
}
