Planet Wars is copyright Luke Wallin 2007-2008 and was inspired by Gravity Wars (Sohrab Ismail-Beigi - 1989 - http://volga.eng.yale.edu/sohrab/personal/gravwars/).

This game makes use of my JavaScript 2D engine and requires either HTML 5's canvas tag (Firefox 1.5+, Opera 9+, Safari 3+) or IE 6+ to work.

Any questions, feel free to contact me at:

http://www.lukewallin.co.uk

luke.wallin@gmail.com